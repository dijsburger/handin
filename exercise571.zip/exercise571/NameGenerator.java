
/**
 * Write a description of class NameGenerator here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class NameGenerator
{
    // instance variables - replace the example below with your own
    private String firstname;
    private String lastname;
    private String mothermaiden;
    private String cityname;
    /**
     * Constructor for objects of class NameGenerator
     */
    public NameGenerator(String first, String last, String mother, String city)
    {
       firstname = first;
       lastname = last;
       mothermaiden = mother;
       cityname = city;
    }
    
    /**
     * Create SW name
     */
    public void Generator()
    {
        String trimfirst = firstname.substring(0, 2);
        String trimlast = lastname.substring(0, 3);
        String trimmother = mothermaiden.substring(0, 2);
        String trimcity = cityname.substring(0, 3);
        String swfirst = trimlast + trimfirst;
        String swlast = trimmother + trimcity;
        System.out.println(swfirst+" "+swlast);
    }
    
    

}
