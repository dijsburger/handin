/**
 * A class that maintains information on a book.
 * This might form part of a larger application such
 * as a library system, for instance.
 *
 * @author (Insert your name here.)
 * @version (Insert today's date here.)
 */
class Book
{
    // The fields.
    private String author;
    private String title;
    private int pages;
    private String number;
    private int borrowed;
    private boolean text;

    /**
     * Set the author and title fields when this object
     * is constructed.
     */
    public Book(String bookAuthor, String bookTitle, int bookPages, boolean courseText)
    {
        author = bookAuthor;
        title = bookTitle;
        pages = bookPages;
        number = "";
        text = courseText;
    }

     /**
     * Here number checked if 3 characters or more
     */
    public void setRefNumber(String setRefNumber){

        if (setRefNumber.length() >=3) {
            number = setRefNumber; 
        }   else {
            System.out.println(" Error, at least 3 characters ");
        }
    }

    public void setBorrow(){
        borrowed ++;
    }

    public String getAuthor()
    {
        return author;
    }

    public String getTitle()
    {
        return title;
    }

    public int getPages()
    {
        return pages;
    }

    public int getBorrow()
    {
        return borrowed;
    }

    public boolean isCourseText()
    {
        return text;
    }

    public void printAuthor()
    {
        System.out.println(author);
    }

    public String getRefNumber()
    {
        return number;
    }

    public void printTitle()
    {
        System.out.println(title);
    }

     /**
     * printDetails checks if there is a Reference Number filled in or not. It will show it on account of the answer
     * is constructed.
     */
    public void printDetails()
    {

        if (number.length() >0)  {
            System.out.println(" Author: "+author+" Title: "+title+" Pages: "+pages+" Ref Number: "+number+" Borrowed: "+borrowed); } 
        else {
            System.out.println(" Author: "+author+" Title: "+title+" Pages: "+pages+" ZZZ "+" Borrowed: "+borrowed);
        }

    }
}